# CSS only toggle buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/kryo2k/pen/dPNqZw](https://codepen.io/kryo2k/pen/dPNqZw).

Supports different control positions, as well as label being clickable like standard labels.